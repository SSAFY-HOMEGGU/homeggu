-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: k11b206.p.ssafy.io    Database: homeggu_goods
-- ------------------------------------------------------
-- Server version	9.1.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `goods_image`
--

DROP TABLE IF EXISTS `goods_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `goods_image` (
  `goods_image_id` int unsigned NOT NULL AUTO_INCREMENT,
  `sales_board_id` int unsigned NOT NULL,
  `goods_image_path` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`goods_image_id`),
  KEY `sales_board_id` (`sales_board_id`),
  CONSTRAINT `goods_image_ibfk_1` FOREIGN KEY (`sales_board_id`) REFERENCES `sales_board` (`sales_board_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goods_image`
--

LOCK TABLES `goods_image` WRITE;
/*!40000 ALTER TABLE `goods_image` DISABLE KEYS */;
INSERT INTO `goods_image` VALUES (1,1,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890268321_%EA%B0%80%EC%8A%B5%EA%B8%B01.PNG'),(2,1,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890270489_%EA%B0%80%EC%8A%B5%EA%B8%B03.PNG'),(3,2,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890924397_2.PNG'),(4,2,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890926121_3.PNG'),(5,2,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890928458_%EC%BA%A1%EC%B2%98.PNG'),(6,3,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890785423_%EC%BA%A1%EC%B2%98.PNG'),(7,3,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890783298_2.PNG'),(8,4,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890808042_%EC%BA%A1%EC%B2%98.PNG'),(9,4,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890804328_2.PNG'),(10,4,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890806254_3.PNG'),(11,5,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890299847_%EB%AF%B8%EB%8B%88%EA%B1%B4%EC%A1%B0%EA%B8%B01.jpg'),(12,5,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890304226_%EB%AF%B8%EB%8B%88%EA%B1%B4%EC%A1%B0%EA%B8%B02.jpg'),(13,5,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890301628_%EB%AF%B8%EB%8B%88%EA%B1%B4%EC%A1%B0%EA%B8%B04.PNG'),(14,6,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890643821_%EC%BA%A1%EC%B2%98.PNG'),(15,6,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890641476_%60.PNG'),(16,6,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890647140_2.PNG'),(17,7,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890467320_%EC%B9%A8%EB%8C%80.PNG'),(18,7,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890471508_%EC%B9%A8%EB%8C%801.PNG'),(19,8,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890956693_%EC%BA%A1%EC%B2%98.PNG'),(20,8,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890955005_%EB%AA%A8%EB%8D%982.PNG'),(21,9,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890834376_%EC%BA%A1%EC%B2%98.PNG'),(22,9,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890832328_%EC%9A%B0%EB%93%9C.PNG'),(23,9,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890830492_1.PNG'),(24,10,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890518196_%EC%BA%A1%EC%B2%98.PNG'),(25,10,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890515920_%E3%85%88%E3%85%82.PNG'),(26,10,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890513727_qwe.PNG'),(27,11,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890331400_%EC%8A%A4%ED%85%90.PNG'),(28,11,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890333361_%EC%8A%A4%ED%85%902.PNG'),(29,11,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890335351_%EC%8A%A4%ED%85%903.PNG'),(30,12,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890672683_%EB%AA%A8%EB%8D%98.PNG'),(31,12,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890670932_2.PNG'),(32,13,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890980642_%EC%BA%A1%EC%B2%98.PNG'),(33,13,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890978311_%EC%86%8C%ED%8C%8C.PNG'),(34,14,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890561897_%EC%BA%A1%EC%B2%98.PNG'),(35,14,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890564217_12.PNG'),(36,14,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890567039_1.PNG'),(37,15,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890859175_2.PNG'),(38,15,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890860820_3.PNG'),(39,15,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890862597_%EC%BA%A1%EC%B2%98.PNG'),(40,16,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890697672_%EC%BA%A1%EC%B2%98.PNG'),(41,16,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890699498_3.PNG'),(42,16,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890701808_2.PNG'),(43,17,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890357377_%EC%B2%AD%EC%86%8C%EA%B8%B01.PNG'),(44,17,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890359222_%EC%B2%AD%EC%86%8C%EA%B8%B02.PNG'),(45,17,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890361025_%EC%B2%AD%EC%86%8C%EA%B8%B03.PNG'),(46,18,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731891002588_%EC%BA%A1%EC%B2%98.PNG'),(47,18,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731891000908_%EC%86%8C%ED%8C%8C.PNG'),(48,19,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890730765_2.PNG'),(49,19,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890732783_%EC%BA%A1%EC%B2%98.PNG'),(50,20,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890384652_%EC%98%A4%EB%94%94%EC%98%A42.PNG'),(51,20,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890386259_%EC%98%A4%EB%94%94%EC%98%A43.PNG'),(52,20,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890388258_%ED%99%88%EC%98%A4%EB%94%94%EC%98%A4.PNG'),(53,21,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890885343_1.PNG'),(54,21,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890886885_2.PNG'),(55,21,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890889147_%EC%BA%A1%EC%B2%98.PNG'),(56,22,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731891058229_%EC%BA%A1%EC%B2%98.PNG'),(57,22,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731891056508_2.PNG'),(58,23,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890753069_%EC%BA%A1%EC%B2%98.PNG'),(59,23,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890750670_2.PNG'),(60,24,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890588114_1.PNG'),(61,24,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890589826_%EC%BA%A1%EC%B2%98.PNG'),(62,24,'https://homeggu-s3.s3.ap-northeast-2.amazonaws.com/1731890591715_%EC%BA%A1%EC%B3%901.PNG');
/*!40000 ALTER TABLE `goods_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 17:55:56
